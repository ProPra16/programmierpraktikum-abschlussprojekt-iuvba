package vk.core.internal;

@SuppressWarnings("serial")
public class InternalCompilerException extends RuntimeException {

	public InternalCompilerException(String message, Exception cause) {
		super(message, cause);
	}
}
